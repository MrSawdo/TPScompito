namespace TPScompito
{
    public partial class Form1 : Form
    {
        private int pacchiSulNastro = 0; // Contatore dei pacchi
        private bool macchinaInFunzione = false; // Stato della macchina
        private readonly object lockObj = new object(); // Oggetto per sincronizzazione
        private Thread aggiungiThread; // Thread per aggiungere pacchi
        private Thread rimuoviThread; // Thread per rimuovere pacchi
        private const int LimitePacchi = 3; // Limite massimo di pacchi sul nastro

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblStato.Text = "Macchina spenta";
            lblStato.ForeColor = System.Drawing.Color.Gray;
            progressBarPacchi.Minimum = 0;
            progressBarPacchi.Maximum = LimitePacchi;
            progressBarPacchi.Value = 0;

            btnStop.Enabled = false;
        }

        private void btnRimuoviPacco_Click(object sender, EventArgs e)
        {
            lock (lockObj)
            {
                if (pacchiSulNastro > 0)
                {
                    pacchiSulNastro--;
                    AggiornaUI();
                }
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            lock (lockObj)
            {
                macchinaInFunzione = true;
            }

            lblStato.Text = "Macchina in funzione";
            lblStato.ForeColor = System.Drawing.Color.Green;

            btnStart.Enabled = false;
            btnStop.Enabled = true;

            // Avvia thread per aggiungere pacchi
            if (aggiungiThread == null || !aggiungiThread.IsAlive)
            {
                aggiungiThread = new Thread(SpostaPacchi);
                aggiungiThread.IsBackground = true;
                aggiungiThread.Start();
            }

            // Avvia thread per rimuovere pacchi
            if (rimuoviThread == null || !rimuoviThread.IsAlive)
            {
                rimuoviThread = new Thread(SmaltisciPacchi);
                rimuoviThread.IsBackground = true;
                rimuoviThread.Start();
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            lock (lockObj)
            {
                macchinaInFunzione = false;
            }

            lblStato.Text = "Macchina spenta";
            lblStato.ForeColor = System.Drawing.Color.Red;

            btnStart.Enabled = true;
            btnStop.Enabled = false;
        }

        private void AggiornaUI()
        {
            if (InvokeRequired)
            {
                Invoke(new Action(AggiornaUI));
                return;
            }

            lblPacchi.Text = $"Pacchi sul nastro: {pacchiSulNastro}";
            progressBarPacchi.Value = Math.Min(pacchiSulNastro, progressBarPacchi.Maximum);

            if (macchinaInFunzione)
            {
                lblStato.Text = "Macchina in funzione";
                lblStato.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                lblStato.Text = pacchiSulNastro >= LimitePacchi ? "Macchina ferma (troppi pacchi)" : "Macchina spenta";
                lblStato.ForeColor = pacchiSulNastro >= LimitePacchi ? System.Drawing.Color.Red : System.Drawing.Color.Gray;
            }
        }

        private void SpostaPacchi()
        {
            while (true)
            {
                Thread.Sleep(1000); // Simula il tempo di aggiunta di un pacco

                lock (lockObj)
                {
                    if (macchinaInFunzione && pacchiSulNastro < LimitePacchi)
                    {
                        pacchiSulNastro++;
                        AggiornaUI();

                        if (pacchiSulNastro >= LimitePacchi)
                        {
                            macchinaInFunzione = false; // Ferma la macchina
                            AggiornaUI();
                        }
                    }
                }
            }
        }

        private void SmaltisciPacchi()
        {
            while (true)
            {
                Thread.Sleep(2000); // Simula il tempo di rimozione di un pacco

                lock (lockObj)
                {
                    if (pacchiSulNastro > 0)
                    {
                        pacchiSulNastro--;
                        AggiornaUI();
                    }
                }
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (aggiungiThread != null && aggiungiThread.IsAlive)
            {
                aggiungiThread.Abort();
            }

            if (rimuoviThread != null && rimuoviThread.IsAlive)
            {
                rimuoviThread.Abort();
            }
        }
    }
}

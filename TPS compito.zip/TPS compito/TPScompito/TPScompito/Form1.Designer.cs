﻿namespace TPScompito
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnStop = new Button();
            btnRimuoviPacco = new Button();
            lblPacchi = new Label();
            progressBarPacchi = new ProgressBar();
            lblStato = new Label();
            btnStart = new Button();
            SuspendLayout();
            // 
            // btnStop
            // 
            btnStop.Location = new Point(142, 132);
            btnStop.Name = "btnStop";
            btnStop.Size = new Size(75, 23);
            btnStop.TabIndex = 1;
            btnStop.Text = "STOP";
            btnStop.UseVisualStyleBackColor = true;
            btnStop.Click += btnStop_Click;
            // 
            // btnRimuoviPacco
            // 
            btnRimuoviPacco.Location = new Point(484, 189);
            btnRimuoviPacco.Name = "btnRimuoviPacco";
            btnRimuoviPacco.Size = new Size(89, 53);
            btnRimuoviPacco.TabIndex = 2;
            btnRimuoviPacco.Text = "RIMUOVI PACCO";
            btnRimuoviPacco.UseVisualStyleBackColor = true;
            btnRimuoviPacco.Click += btnRimuoviPacco_Click;
            // 
            // lblPacchi
            // 
            lblPacchi.AutoSize = true;
            lblPacchi.Location = new Point(540, 171);
            lblPacchi.Name = "lblPacchi";
            lblPacchi.Size = new Size(87, 15);
            lblPacchi.TabIndex = 3;
            lblPacchi.Text = "numero pacchi";
            // 
            // progressBarPacchi
            // 
            progressBarPacchi.Location = new Point(603, 189);
            progressBarPacchi.Name = "progressBarPacchi";
            progressBarPacchi.Size = new Size(100, 23);
            progressBarPacchi.TabIndex = 4;
            // 
            // lblStato
            // 
            lblStato.AutoSize = true;
            lblStato.Location = new Point(112, 171);
            lblStato.Name = "lblStato";
            lblStato.Size = new Size(39, 15);
            lblStato.TabIndex = 5;
            lblStato.Text = "STATO";
            // 
            // btnStart
            // 
            btnStart.Location = new Point(43, 132);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(75, 23);
            btnStart.TabIndex = 6;
            btnStart.Text = "START";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnStart);
            Controls.Add(lblStato);
            Controls.Add(progressBarPacchi);
            Controls.Add(lblPacchi);
            Controls.Add(btnRimuoviPacco);
            Controls.Add(btnStop);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnStop;
        private Button btnRimuoviPacco;
        private Label lblPacchi;
        private ProgressBar progressBarPacchi;
        private Label lblStato;
        private Button btnStart;
    }
}
